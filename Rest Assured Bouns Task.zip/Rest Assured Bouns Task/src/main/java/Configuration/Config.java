package Configuration;

public class Config {

    public final String BaseUrl = "https://opensource-demo.orangehrmlive.com";
    public final String viewCandidates = "/web/index.php/recruitment/viewCandidates";

    public final String Login = "/web/index.php/auth/validate";


}


