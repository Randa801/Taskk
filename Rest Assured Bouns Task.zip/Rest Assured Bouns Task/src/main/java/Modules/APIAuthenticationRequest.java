package Modules;
import Configuration.Config;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.JSONObject;
public class APIAuthenticationRequest {
    static Config config = new Config();
    public static Response login(String Username , String Password){
        JSONObject data = new JSONObject();
        data.put("Username", Username);
        data.put("Password", Password);
        return RestAssured.given().log().all()
                .header("Content-Type","application/json")
                .body(data.toString())
                .post(config.BaseUrl+config.Login).then().extract().response();
    }
}
