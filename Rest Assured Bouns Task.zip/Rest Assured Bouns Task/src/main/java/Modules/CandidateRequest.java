package Modules;

import java.util.List;

public class CandidateRequest {
    private String candidateName;
    private List<Object> jobTitle;
    private List<Object> methodOfApp;
    private List<Object> status;
    private List<Object> hiringManager;
    private List<Object> vacancy;
    public CandidateRequest(){

    }
    public CandidateRequest(String candidateName, List<Object> jobTitle, List<Object> methodOfApp , List<Object> status , List<Object> hiringManager , List<Object> vacancy) {
        this.candidateName = candidateName;
        this.jobTitle = jobTitle;
        this.methodOfApp = methodOfApp;
        this.status = status;
        this.hiringManager = hiringManager;
        this.vacancy = vacancy;
    }
    public String getCandidateName() {
        return candidateName;
    }
    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public List<Object> getJobTitle() {
        return jobTitle;
    }
    public void setJobTitle(List<Object> jobTitle) {
        this.jobTitle = jobTitle;
    }

    public List<Object> getMethodOfApp() {
        return methodOfApp;
    }
    public void setMethodOfApp(List<Object> methodOfApp) {
        this.methodOfApp = methodOfApp;
    }

    public List<Object> getStatus() {
        return status;
    }
    public void setStatus(List<Object> status) {this.status = status; }

    public List<Object> getHiringManager() {
        return hiringManager;
    }
    public void setHiringManager(List<Object> hiringManager) {this.hiringManager = hiringManager; }

    public List<Object> getVacancy() {
        return vacancy;
    }
    public void setVacancy(List<Object> vacancy) {this.vacancy = vacancy; }

}
