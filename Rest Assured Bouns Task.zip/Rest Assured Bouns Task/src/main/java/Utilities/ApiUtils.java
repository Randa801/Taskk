package Utilities;

import Modules.APIAuthenticationRequest;
import Utilities.TestData.Constant;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

public class ApiUtils {
    public static String GenerateAuthToken (){
         JsonPath jsonPath = APIAuthenticationRequest.login(Constant.USERNAME,Constant.PASSWORD).jsonPath();
        String AuthToken = jsonPath.getString("accessToken");
        return AuthToken;
    }
    public Response postWithAuth(String endpoint , Object data){
        Response response=  given().log().all()
                .header("Authorization", GenerateAuthToken())
                .header("Content-Type", "application/json")
                .body(data)
                .post(endpoint).then().log().all().extract().response();
        return response;

    }

    public Response GetWithAuth(String endpoint ){
        Response response=  given().log().all()
                .header("Authorization", GenerateAuthToken())
                .header("Content-Type", "application/json")
                .get(endpoint).then().log().all().extract().response();
        return response;

    }
}
