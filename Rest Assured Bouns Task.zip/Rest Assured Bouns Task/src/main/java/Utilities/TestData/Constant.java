package Utilities.TestData;

public class Constant {
    public static  String USERNAME = "Admin";
    public static String PASSWORD = "admin123";

}
