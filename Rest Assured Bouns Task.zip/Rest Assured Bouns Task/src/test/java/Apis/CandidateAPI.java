package Apis;

import Modules.CandidateRequest;

public class CandidateAPI {
    public CandidateRequest addCandidate(){
        CandidateRequest request = new CandidateRequest();
        request.setCandidateName();
        request.setJobTitle();
        request.setHiringManager();
        request.setStatus();
        request.setMethodOfApp();
        request.setVacancy();
        return request;
    }
}
