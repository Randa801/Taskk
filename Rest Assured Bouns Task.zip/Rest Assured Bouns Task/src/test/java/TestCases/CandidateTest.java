package TestCases;

public class CandidateTest {
}
