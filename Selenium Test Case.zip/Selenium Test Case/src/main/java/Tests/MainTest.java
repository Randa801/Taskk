package Tests;

import org.Pages.Main;
import org.testng.annotations.Test;

public class MainTest extends BaseTest {
 Main main;
@Test
    public void testScenario() throws InterruptedException {
    Main main = new Main(driver);
    loginWithValidData();
    Thread.sleep(10000);
    main.Test();
}
}
