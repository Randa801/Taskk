package org.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {
    public WebDriver driver;
    public Main(WebDriver driver){
        this.driver = driver;}
public void Test() throws InterruptedException {
    clickMenuTab();
    Thread.sleep(1000);
    System.out.println(initialRecordsCount);
    Thread.sleep(1000);
    clickAddButton();
    Thread.sleep(1000);
    enterName();
    Thread.sleep(1000);
    clickUserRoleDDL();
    Thread.sleep(1000);
    clickStatusDDL();
    Thread.sleep(1000);
    enterPassword();
    Thread.sleep(1000);
    enterConfirmPassword();
    Thread.sleep(1000);
    clickSaveButton();
    Thread.sleep(1000);
    recordsIncreasedOne();
    Thread.sleep(1000);
    enterSearchUser();
    Thread.sleep(1000);
    clickSearchButton();
    Thread.sleep(1000);
    clickDeleteUser();
    Thread.sleep(1000);
    recordsDecreasedOne();
    Thread.sleep(1000);
}
    // Step 2: Enter username
    By username = By.name("username");
    public void enterUsername(String name) {
        driver.findElement(username).sendKeys(name);
    }

    // Step 3: Enter password
    By password1 = By.name("password");
    public void enterPasword(String password) {
        driver.findElement(password1).sendKeys(password);
    }

    // Step 4: Click on the login button
    By loginButton = By.xpath("//button[@type='submit']");
    public void clickLoginButton() {
        driver.findElement(loginButton).click(); }

    // Step 5: Click on Admin tab
    By adminTab = By.xpath("//a[@href='/web/index.php/admin/viewAdminModule']");
    public void clickMenuTab() {
        driver.findElement(adminTab).click();
    }

    // Step 6: Get the number of records found

        WebElement recordsFound = driver.findElement(By.xpath("//div[@class='oxd-table-filter-area']//div[@class='oxd-table-filter-item']"));
        String initialRecords = recordsFound.getText().split(" ")[0];
        int initialRecordsCount = Integer.parseInt(initialRecords);

    // Step 7: Click on add button
    By addButton = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--secondary']");
    public void clickAddButton() { driver.findElement(addButton).click(); }

    // Step 8: Fill the required data
    By Username = By.xpath("//input[@name='username']");
    public void enterName() {
        driver.findElement(Username).sendKeys("Randa");
    }
    By userRole = By.xpath("//div[@class='oxd-select-text-input']");
    By adminRole = By.xpath("//div[@role='option'][1]");
    public void clickUserRoleDDL() {
        driver.findElement(userRole).click();
       driver.findElement(adminRole).click(); }
    By status = By.xpath("//div[@class='oxd-select-text-input']");
    By enableStatus = By.xpath("//div[@role='option'][1]");
    public void clickStatusDDL() {
        driver.findElement(status).click();
        driver.findElement(enableStatus).click(); }

    By Password = By.xpath("//input[@type='password']");
    public void enterPassword() {
        driver.findElement(Password).sendKeys("password123");
    }
    By ConfirmPassword = By.xpath("//input[@type='password'][2]");
    public void enterConfirmPassword() {
        driver.findElement(ConfirmPassword).sendKeys("password123");
    }

    // Step 9: Click on save button
    By saveButton = By.xpath("//button[@type='submit']");
    public void clickSaveButton() {
        driver.findElement(saveButton).click();
    }

    // Step 10: Verify that the number of records increased by 1
    public void recordsIncreasedOne(){
        WebElement recordsFounds = driver.findElement(By.xpath("//div[@class='oxd-table-filter-area']//div[@class='oxd-table-filter-item']"));
        String updatedRecords = recordsFound.getText().split(" ")[0];
        int updatedRecordsCount = Integer.parseInt(updatedRecords);
        updatedRecordsCount = initialRecordsCount + 1;
        System.out.println(updatedRecordsCount);
    }

    // Step 11: Search with the username for the new user
    By searchUser = By.xpath("//input[@placeholder='Type for hints...']");
    public void enterSearchUser(){driver.findElement(searchUser).sendKeys("Randa");}
    By searchButton = By.xpath("//button[contains(.,'Search')]");
    public void clickSearchButton(){driver.findElement(searchButton).click();}

    // Step 12: Delete the new user
    By DeleteButton = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--label-danger']");
    public void clickDeleteUser(){driver.findElement(DeleteButton).click();}

    // Step 13: Verify the deletion by checking for absence of username
    public void recordsDecreasedOne(){
        WebElement recordsFounds = driver.findElement(By.xpath("//div[@class='oxd-table-filter-area']//div[@class='oxd-table-filter-item']"));
        String updatedRecords = recordsFound.getText().split(" ")[0];
        int updatedRecordsCount1 = Integer.parseInt(updatedRecords);
        updatedRecordsCount1 = initialRecordsCount - 1;
        System.out.println(updatedRecordsCount1);
    }

}